module BinarySearch {
}